function matlab_model(arg1, arg2)
  if nargin < 1
    arg1 = 'default';
  end
  if nargin < 2
    arg2 = 0;
  end
  pause(1);
  disp('Matlab model.');
end
