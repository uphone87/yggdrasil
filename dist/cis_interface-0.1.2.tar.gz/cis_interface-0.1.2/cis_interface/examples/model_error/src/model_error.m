% Raise an error or return non-zero value
error('Test error');
exit(-1);
