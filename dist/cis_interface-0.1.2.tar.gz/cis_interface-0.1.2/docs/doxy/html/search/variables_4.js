var searchData=
[
  ['io_5fmode',['io_mode',['../structasciiFile__t.html#a89b8b86d814353fea003c9c54204d8af',1,'asciiFile_t']]]
];
