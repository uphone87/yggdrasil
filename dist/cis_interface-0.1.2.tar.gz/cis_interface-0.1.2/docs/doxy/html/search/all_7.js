var searchData=
[
  ['ncols',['ncols',['../structasciiTable__t.html#a837095bd2a245987e98f2bdd1fccaa94',1,'asciiTable_t']]],
  ['newline',['newline',['../structasciiFile__t.html#aa98795a5f431ada3d3548bc9b29c936f',1,'asciiFile_t']]]
];
