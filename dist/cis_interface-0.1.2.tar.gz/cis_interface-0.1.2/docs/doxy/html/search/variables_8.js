var searchData=
[
  ['status',['status',['../structasciiTable__t.html#a3a1b4f901f6cad135a0600a22942c43b',1,'asciiTable_t']]]
];
