.. cis_interface documentation master file, created by
   sphinx-quickstart on Wed Sep  6 12:03:29 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cis_interface's documentation!
=========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   includeme
   install
   config
   code

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
