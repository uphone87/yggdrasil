int main(int argc, char *argv[]) {
  // Throw an error or return a non-zero value to indicate an error
  throw "Test error";
  return -1;
}
