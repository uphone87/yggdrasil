r"""Tests for io sub-package."""

__all__ = []
