raise Exception('Python model')
