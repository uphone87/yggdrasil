#include<stdio.h>
#include <unistd.h>

int main() {
  sleep(1);
  printf("GCC Model\n");
  return 0;
}
