var searchData=
[
  ['msgbuf_5ft',['msgbuf_t',['../structmsgbuf__t.html',1,'']]]
];
