var searchData=
[
  ['msgbuf_5ft',['msgbuf_t',['../structmsgbuf__t.html',1,'']]],
  ['mtype',['mtype',['../structmsgbuf__t.html#a94084fefd8e8fb9a97ad4aab296ca9c4',1,'msgbuf_t']]]
];
