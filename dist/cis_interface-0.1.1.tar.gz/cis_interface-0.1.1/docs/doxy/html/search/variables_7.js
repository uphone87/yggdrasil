var searchData=
[
  ['row_5fsiz',['row_siz',['../structasciiTable__t.html#aaa2f0c09c59e6b4cdad4e3845552da35',1,'asciiTable_t']]]
];
