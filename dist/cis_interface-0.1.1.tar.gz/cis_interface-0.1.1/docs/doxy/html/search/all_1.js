var searchData=
[
  ['asciifile_5ft',['asciiFile_t',['../structasciiFile__t.html',1,'']]],
  ['asciitable_5ft',['asciiTable_t',['../structasciiTable__t.html',1,'']]]
];
