var searchData=
[
  ['column',['column',['../structasciiTable__t.html#a4c09956acb7a76e0431d9deb6f27be7e',1,'asciiTable_t']]],
  ['comment',['comment',['../structasciiFile__t.html#aa6b01ebf820bd2c7bc7003e7b0669092',1,'asciiFile_t']]]
];
